import './LoginPage.css';

function LoginPage() {
  return (
      <div className="LoginPage">
       <h1>Login Page</h1>
      </div>
    );
}

export default LoginPage;
