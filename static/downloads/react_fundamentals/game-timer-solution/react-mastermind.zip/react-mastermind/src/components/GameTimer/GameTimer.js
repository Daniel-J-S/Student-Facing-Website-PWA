import { useEffect, useRef } from 'react';
import styles from './GameTimer.module.css';
import { formatTime } from '../../services/utilities';

const GameTimer = (props) => {
    const savedCallback = useRef();

    function handleTick() {
      props.handleTimerUpdate();
    }

    useEffect(() => {
      savedCallback.current = handleTick;
    });

    useEffect(() => {
      const timerId = setInterval(savedCallback.current, 1000);
      return () => clearInterval(timerId)
    }, []);
    
  return (
    <div className={styles.GameTimer}>
      {formatTime(props.elapsedTime)}
    </div>
  );
}

export default GameTimer;
