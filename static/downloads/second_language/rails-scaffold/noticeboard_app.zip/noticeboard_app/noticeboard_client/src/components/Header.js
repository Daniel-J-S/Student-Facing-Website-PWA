function Header(props) {
    return (
      <header>
        <h1>Notices</h1>
      </header>
    );
}

export default Header;
